<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        User::factory()->create([
            'nom' => 'Admin',
            'prenom' => 'System',
            'email' => 'admin@example.com',
            'role' => 'admin',
            'password' => bcrypt('password'),
            'email_verified_at' => now(),
        ]);

        // Create a sample student account for testing
        User::factory()->create([
            'nom' => 'Etudiant',
            'prenom' => 'Demo',
            'email' => 'student@example.com',
            'role' => 'etudiant',
            'password' => bcrypt('password'),
            'email_verified_at' => now(),
        ]);
    }
}
