<?php

use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\EtudiantController;
use App\Http\Controllers\FiliereController;
use App\Http\Controllers\InscriptionController;
use App\Http\Controllers\MatiereController;
use App\Http\Controllers\ModuleController;
use App\Http\Controllers\NiveauController;
use App\Http\Controllers\NoteController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProfesseurController;
use App\Http\Controllers\ResultatAnnuelController;
use App\Http\Controllers\ResultatSemestreController;
use App\Http\Controllers\ProgressionEtudiantController;
use App\Http\Controllers\DetteController;
use App\Http\Controllers\EmploiDuTempsController;
use App\Http\Controllers\SemestreController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return view('home');
})->name('home');

require __DIR__ . '/auth.php';

Route::middleware('auth')->group(function () {
    Route::get('attente', [AuthController::class, 'attente'])
        ->name('attente');

    Route::get('inscription/attente', [AuthController::class, 'attente'])
        ->name('inscription.attente');

    Route::get('attente-approbation', [AuthController::class, 'attente'])
        ->name('attente.approbation');

    Route::prefix('admin')->name('admin.')->middleware('role:admin')->group(function () {
        Route::get('dashboard', [DashboardController::class, 'adminDashboard'])
            ->name('dashboard');

        Route::get('inscriptions', [InscriptionController::class, 'index'])
            ->name('inscriptions.index');

        Route::get('inscriptions/{inscription}', [InscriptionController::class, 'show'])
            ->name('inscriptions.show');

        Route::put('inscriptions/{inscription}/approve', [InscriptionController::class, 'approuver'])
            ->name('inscriptions.approve');

        Route::put('inscriptions/{inscription}/refuse', [InscriptionController::class, 'refuser'])
            ->name('inscriptions.refuse');

        Route::resource('filieres', FiliereController::class);
        Route::resource('etudiants', EtudiantController::class);
        Route::resource('professeurs', ProfesseurController::class);
        Route::resource('niveaux', NiveauController::class);
        Route::resource('semestres', SemestreController::class);
        Route::resource('modules', ModuleController::class);
        Route::resource('matieres', MatiereController::class);
        Route::resource('notes', NoteController::class);
        Route::resource('dettes', DetteController::class);
        Route::resource('emplois', EmploiDuTempsController::class);

        Route::get('resultats/semestre', [ResultatSemestreController::class, 'index'])
            ->name('resultats.semestre.index');

        Route::get('resultats/annuel', [ResultatAnnuelController::class, 'index'])
            ->name('resultats.annuel.index');

        Route::get('progression', [ProgressionEtudiantController::class, 'index'])
            ->name('progression.index');
    });

    Route::prefix('etudiant')->name('etudiant.')->middleware('role:etudiant')->group(function () {
        Route::get('dashboard', [DashboardController::class, 'etudiantDashboard'])
            ->name('dashboard');

        Route::get('notes', [DashboardController::class, 'etudiantNotes'])
            ->name('notes.index');

        Route::get('bulletin', [DashboardController::class, 'etudiantBulletin'])
            ->name('bulletin.index');

        Route::get('modules', [DashboardController::class, 'etudiantModules'])
            ->name('modules.index');

        Route::get('matieres', [DashboardController::class, 'etudiantMatieres'])
            ->name('matieres.index');

        Route::get('dettes', [DashboardController::class, 'etudiantDettes'])
            ->name('dettes.index');

        Route::get('emploi', [DashboardController::class, 'etudiantEmploi'])
            ->name('emploi.index');

        Route::get('profil', [ProfileController::class, 'edit'])
            ->name('profil.index');

        Route::put('profil', [ProfileController::class, 'update'])
            ->name('profil.update');

        Route::delete('profil', [ProfileController::class, 'destroy'])
            ->name('profil.destroy');
    });
});
