@props(['active'])

@php
$classes = ($active ?? false)
? 'inline-flex items-center px-3 py-2 rounded-full bg-[#F53003] text-sm font-semibold text-white shadow-sm shadow-[#F53003]/20 focus:outline-none transition duration-150 ease-in-out'
: 'inline-flex items-center px-3 py-2 rounded-full text-sm font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-300 dark:hover:text-white dark:hover:bg-slate-800 focus:outline-none transition duration-150 ease-in-out';
@endphp

<a {{ $attributes->merge(['class' => $classes]) }}>
    {{ $slot }}
</a>