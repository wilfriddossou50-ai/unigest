@extends('layouts.admin')

@section('title', 'Gestion de l\'Emploi du Temps')

@section('content')
<div class="p-8">
    <!-- Header -->
    <div class="flex items-center justify-between mb-8">
        <div>
            <h1 class="text-3xl font-bold text-slate-900">Emploi du Temps</h1>
            <p class="text-slate-600 mt-1">Gérez l'organisation des cours</p>
        </div>
        <a href="{{ route('admin.emplois.create') }}" class="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition">
            <i data-lucide="plus" class="w-5 h-5"></i>
            Ajouter cours
        </a>
    </div>

    <!-- Filters -->
    <div class="bg-white rounded-xl shadow-sm p-6 mb-6">
        <form action="{{ route('admin.emplois.index') }}" method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <select name="niveau_id" class="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">Tous les niveaux</option>
                @foreach($niveaux as $niveau)
                <option value="{{ $niveau->id }}" {{ request('niveau_id') == $niveau->id ? 'selected' : '' }}>{{ $niveau->libelle }}</option>
                @endforeach
            </select>

            <select name="semestre_id" class="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">Tous les semestres</option>
                @foreach($semestres as $semestre)
                <option value="{{ $semestre->id }}" {{ request('semestre_id') == $semestre->id ? 'selected' : '' }}>{{ $semestre->libelle }}</option>
                @endforeach
            </select>

            <select name="jour" class="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">Tous les jours</option>
                @foreach(['Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'] as $jour)
                <option value="{{ $jour }}" {{ request('jour') == $jour ? 'selected' : '' }}>{{ $jour }}</option>
                @endforeach
            </select>

            <button type="submit" class="bg-slate-100 hover:bg-slate-200 text-slate-900 px-4 py-2 rounded-lg transition">Filtrer</button>
        </form>
    </div>

    <!-- Table -->
    <div class="bg-white rounded-xl shadow-sm overflow-hidden">
        <table class="w-full">
            <thead class="bg-slate-50 border-b border-slate-200">
                <tr>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Matière</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Professeur</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Jour</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Heure</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Salle</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Semestre</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Niveau</th>
                    <th class="px-6 py-4 text-right text-sm font-semibold text-slate-900">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-200">
                @forelse($emplois ?? [] as $emploi)
                <tr class="hover:bg-slate-50 transition">
                    <td class="px-6 py-4 text-sm font-medium text-slate-900">{{ $emploi->matiere->libelle ?? 'N/A' }}</td>
                    <td class="px-6 py-4 text-sm text-slate-600">{{ $emploi->professeur->nom ?? '' }} {{ $emploi->professeur->prenom ?? '' }}</td>
                    <td class="px-6 py-4 text-sm text-slate-600">{{ ucfirst($emploi->jour ?? 'N/A') }}</td>
                    <td class="px-6 py-4 text-sm text-slate-900 font-medium">{{ $emploi->heure_debut ?? 'N/A' }} - {{ $emploi->heure_fin ?? 'N/A' }}</td>
                    <td class="px-6 py-4 text-sm text-slate-600">{{ $emploi->salle ?? 'N/A' }}</td>
                    <td class="px-6 py-4 text-sm text-slate-600">{{ $emploi->semestre->libelle ?? 'N/A' }}</td>
                    <td class="px-6 py-4 text-sm text-slate-600">{{ $emploi->niveau->libelle ?? 'N/A' }}</td>
                    <td class="px-6 py-4 text-sm text-right">
                        <form action="{{ route('admin.emplois.destroy', $emploi) }}" method="POST" class="inline" onsubmit="return confirm('Êtes-vous sûr ?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-red-600 hover:text-red-700">
                                <i data-lucide="trash" class="w-4 h-4"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="8" class="px-6 py-8 text-center text-slate-500">
                        Aucun cours programmé
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<script>
    lucide.createIcons();
</script>
@endsection