@extends('layouts.admin')

@section('title', 'Gestion des Notes')

@section('content')
<div class="p-8">
    <!-- Header -->
    <div class="flex items-center justify-between mb-8">
        <div>
            <h1 class="text-3xl font-bold text-slate-900">Notes</h1>
            <p class="text-slate-600 mt-1">Gérez les notes des étudiants</p>
        </div>
        <a href="{{ route('admin.notes.create') }}" class="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition">
            <i data-lucide="plus" class="w-5 h-5"></i>
            Ajouter note
        </a>
    </div>

    <!-- Filters -->
    <form method="GET" action="{{ route('admin.notes.index') }}" class="bg-white rounded-xl shadow-sm p-6 mb-6">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <select name="matiere_id" class="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">Toutes les matières</option>
                @foreach($matieres as $matiere)
                <option value="{{ $matiere->id }}" {{ request('matiere_id') == $matiere->id ? 'selected' : '' }}>
                    {{ $matiere->libelle }}
                </option>
                @endforeach
            </select>
            <select name="etudiant_id" class="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">Tous les étudiants</option>
                @foreach($etudiants as $etudiant)
                <option value="{{ $etudiant->id }}" {{ request('etudiant_id') == $etudiant->id ? 'selected' : '' }}>
                    {{ $etudiant->user->nom ?? '' }} {{ $etudiant->user->prenom ?? '' }}
                </option>
                @endforeach
            </select>
            <select name="semestre_id" class="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">Tous les semestres</option>
                @foreach($semestres as $semestre)
                <option value="{{ $semestre->id }}" {{ request('semestre_id') == $semestre->id ? 'selected' : '' }}>
                    {{ $semestre->libelle }}
                </option>
                @endforeach
            </select>
            <button type="submit" class="bg-slate-100 hover:bg-slate-200 text-slate-900 px-4 py-2 rounded-lg transition">Filtrer</button>
        </div>
    </form>

    <!-- Table -->
    <div class="bg-white rounded-xl shadow-sm overflow-hidden">
        <table class="w-full">
            <thead class="bg-slate-50 border-b border-slate-200">
                <tr>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Étudiant</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Matière</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Filière</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Contrôle continu</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Examen</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Note finale</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Statut</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-200">
                @forelse($notes ?? [] as $note)
                <tr class="hover:bg-slate-50 transition">
                    <td class="px-6 py-4 text-sm font-medium text-slate-900">{{ $note->etudiant->user->nom ?? '' }} {{ $note->etudiant->user->prenom ?? '' }}</td>
                    <td class="px-6 py-4 text-sm text-slate-600">{{ $note->matiere->libelle ?? 'N/A' }}</td>
                    <td class="px-6 py-4 text-sm text-slate-600">{{ $note->matiere->module->filiere->libelle ?? 'N/A' }}</td>
                    <td class="px-6 py-4 text-sm text-slate-900 font-medium">{{ $note->cc ?? '-' }}/20</td>
                    <td class="px-6 py-4 text-sm text-slate-900 font-medium">{{ $note->examen ?? '-' }}/20</td>
                    <td class="px-6 py-4 text-sm font-semibold text-slate-900">{{ $note->note_finale ?? '-' }}/20</td>
                    <td class="px-6 py-4 text-sm">
                        <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold {{ in_array($note->statut, ['validee', 'rattrapage_valide', 'reprise_valide'], true) ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800' }}">
                            {{ ucfirst($note->statut ?? 'en attente') }}
                        </span>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" class="px-6 py-8 text-center text-slate-500">
                        Aucune note trouvée
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<script>
    lucide.createIcons();
</script>
@endsection
