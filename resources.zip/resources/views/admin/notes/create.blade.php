@extends('layouts.admin')

@section('title', 'Ajouter une Note')

@section('content')
<div class="p-8">
    <div class="mb-8">
        <a href="{{ route('admin.notes.index') }}" class="text-blue-600 hover:text-blue-700 text-sm font-medium mb-4 inline-block">
            ← Retour aux notes
        </a>
        <h1 class="text-3xl font-bold text-slate-900">Ajouter une Note</h1>
    </div>

    <div class="bg-white rounded-3xl border border-slate-200 shadow-sm p-8 max-w-3xl">
        @if($etudiants->isEmpty() || $matieres->isEmpty())
        <div class="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
            Ajoutez d'abord au moins un étudiant actif et une matière avant d'enregistrer une note.
        </div>
        @else
        <form action="{{ route('admin.notes.store') }}" method="POST" class="space-y-6">
            @csrf

            <div>
                <label class="block text-sm font-semibold text-slate-900 mb-2">Étudiant *</label>
                <select name="etudiant_id" required class="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 @error('etudiant_id') border-red-500 @enderror">
                    <option value="">Sélectionnez un étudiant</option>
                    @foreach($etudiants as $etudiant)
                    <option value="{{ $etudiant->id }}" {{ old('etudiant_id') == $etudiant->id ? 'selected' : '' }}>
                        {{ $etudiant->user->nom ?? '' }} {{ $etudiant->user->prenom ?? '' }} — {{ $etudiant->filiere->libelle ?? 'Filière inconnue' }} — {{ $etudiant->niveau->libelle ?? 'Niveau inconnu' }}
                    </option>
                    @endforeach
                </select>
                @error('etudiant_id')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-semibold text-slate-900 mb-2">Matière *</label>
                <select name="matiere_id" required class="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 @error('matiere_id') border-red-500 @enderror">
                    <option value="">Sélectionnez une matière</option>
                    @foreach($matieres as $matiere)
                    <option value="{{ $matiere->id }}" {{ old('matiere_id') == $matiere->id ? 'selected' : '' }}>
                        {{ $matiere->libelle ?? $matiere->code }} — {{ $matiere->module->nom ?? 'Module inconnu' }} — {{ $matiere->module->filiere->libelle ?? 'Filière inconnue' }}
                    </option>
                    @endforeach
                </select>
                @error('matiere_id')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-semibold text-slate-900 mb-2">Contrôle continu *</label>
                <input type="number" name="cc" value="{{ old('cc') }}" min="0" max="20" step="0.1" required class="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 @error('cc') border-red-500 @enderror" placeholder="Ex: 12.5">
                @error('cc')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="block text-sm font-semibold text-slate-900 mb-2">Examen *</label>
                <input type="number" name="examen" value="{{ old('examen') }}" min="0" max="20" step="0.1" required class="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 @error('examen') border-red-500 @enderror" placeholder="Ex: 15.0">
                @error('examen')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="flex gap-4 pt-4 border-t border-slate-200">
                <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2.5 rounded-lg transition">
                    Enregistrer la note
                </button>
                <a href="{{ route('admin.notes.index') }}" class="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-900 font-medium py-2.5 rounded-lg transition text-center">
                    Annuler
                </a>
            </div>
        </form>
        @endif
    </div>
</div>

<script>
    lucide.createIcons();
</script>
@endsection
