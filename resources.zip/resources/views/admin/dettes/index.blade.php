@extends('layouts.admin')

@section('title', 'Gestion des Dettes')

@section('content')
<div class="p-8">
    <!-- Header -->
    <div class="flex items-center justify-between mb-8">
        <div>
            <h1 class="text-3xl font-bold text-slate-900">Dettes académiques</h1>
            <p class="text-slate-600 mt-1">Suivi des matières non encore validées</p>
        </div>
    </div>

    <!-- Stats -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="bg-white rounded-xl shadow-sm p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-slate-600">Dettes en cours</p>
                    <p class="text-2xl font-bold text-slate-900 mt-2">{{ $dettes->count() }}</p>
                </div>
                <i data-lucide="alert-circle" class="w-10 h-10 text-red-600 opacity-20"></i>
            </div>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-slate-600">Étudiants concernés</p>
                    <p class="text-2xl font-bold text-slate-900 mt-2">{{ $dettes->pluck('etudiant_id')->unique()->count() }}</p>
                </div>
                <i data-lucide="users" class="w-10 h-10 text-orange-600 opacity-20"></i>
            </div>
        </div>
        <div class="bg-white rounded-xl shadow-sm p-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-slate-600">Dettes levées</p>
                    <p class="text-2xl font-bold text-slate-900 mt-2">{{ $levees ?? 0 }}</p>
                </div>
                <i data-lucide="check-circle" class="w-10 h-10 text-green-600 opacity-20"></i>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="bg-white rounded-xl shadow-sm p-6 mb-6">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <select class="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">Tous les statuts</option>
                <option value="en_cours">En cours</option>
                <option value="levee">Levée</option>
            </select>
            <select class="px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">Tous les niveaux</option>
            </select>
            <button class="bg-slate-100 hover:bg-slate-200 text-slate-900 px-4 py-2 rounded-lg transition">Filtrer</button>
        </div>
    </div>

    <!-- Table -->
    <div class="bg-white rounded-xl shadow-sm overflow-hidden">
        <table class="w-full">
            <thead class="bg-slate-50 border-b border-slate-200">
                <tr>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Étudiant</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Module</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Matière</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Semestre</th>
                    <th class="px-6 py-4 text-left text-sm font-semibold text-slate-900">Statut</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-200">
                @forelse($dettes ?? [] as $dette)
                <tr class="hover:bg-slate-50 transition">
                    <td class="px-6 py-4 text-sm font-medium text-slate-900">{{ $dette->etudiant->user->nom ?? '' }} {{ $dette->etudiant->user->prenom ?? '' }}</td>
                    <td class="px-6 py-4 text-sm text-slate-600">{{ $dette->module->nom ?? 'N/A' }}</td>
                    <td class="px-6 py-4 text-sm text-slate-600">{{ $dette->matiere->libelle ?? 'N/A' }}</td>
                    <td class="px-6 py-4 text-sm text-slate-600">{{ $dette->semestre->libelle ?? 'N/A' }}</td>
                    <td class="px-6 py-4 text-sm">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium {{ $dette->statut === 'en_cours' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800' }}">
                            {{ ucfirst(str_replace('_', ' ', $dette->statut ?? 'en_cours')) }}
                        </span>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" class="px-6 py-8 text-center text-slate-500">
                        Aucune dette enregistrée
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<script>
    lucide.createIcons();
</script>
@endsection
