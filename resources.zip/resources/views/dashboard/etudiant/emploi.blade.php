@extends('layouts.etudiant')

@section('title', 'Emploi du temps')
@section('subtitle', 'Votre planning académique')

@section('content')
<div x-data="{ ready: false }" x-init="setTimeout(() => ready = true, 50)" class="space-y-6">
    <!-- HEADER -->
    <div :class="ready ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'"
        class="rounded-2xl bg-white p-6 border border-slate-200 shadow-md transition-all duration-700 ease-out">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-bold text-slate-900">Emploi du temps</h1>
                <p class="mt-1 text-sm text-slate-600">Votre planning et vos séances</p>
            </div>
            <a href="{{ route('etudiant.dashboard') }}" class="inline-flex items-center gap-2 rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100 transition">
                <i data-lucide="arrow-left" class="w-4 h-4"></i>
                Retour
            </a>
        </div>
    </div>

    @if($emplois->isNotEmpty())
    <!-- SCHEDULE TABLE -->
    <div class="rounded-2xl bg-white border border-slate-200 shadow-md overflow-hidden">
        <div class="px-6 py-5 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-slate-100">
            <h2 class="text-lg font-semibold text-slate-900">Planning par jour</h2>
        </div>
        
        @php
            $emploisGroupedByDay = $emplois->groupBy('jour');
            $daysOrder = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
        @endphp

        <div class="overflow-x-auto">
            <div class="space-y-4 p-6">
                @foreach($daysOrder as $day)
                    @if($emploisGroupedByDay->has($day))
                    <div class="border border-slate-200 rounded-xl overflow-hidden">
                        <div class="bg-gradient-to-r from-indigo-50 to-blue-50 px-4 py-3 font-semibold text-slate-900">
                            {{ $day }}
                        </div>
                        <div class="space-y-2 p-4">
                            @foreach($emploisGroupedByDay[$day]->sortBy('heure_debut') as $emploi)
                            <div class="flex gap-4 rounded-lg border-l-4 border-indigo-500 bg-indigo-50 p-4 hover:bg-indigo-100 transition">
                                <div class="flex-shrink-0">
                                    <div class="inline-flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600 text-white text-xs font-bold">
                                        <i data-lucide="clock" class="w-5 h-5"></i>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <div class="flex items-start justify-between gap-2">
                                        <div>
                                            <h4 class="font-semibold text-slate-900">{{ $emploi->matiere?->libelle ?? '—' }}</h4>
                                            <p class="text-sm text-slate-600 mt-1">
                                                {{ $emploi->matiere?->module?->nom ?? '—' }}
                                                @if($emploi->professeur)
                                                    <span class="ml-2 text-indigo-600 font-medium">• {{ $emploi->professeur->nom }}</span>
                                                @endif
                                            </p>
                                        </div>
                                        <span class="inline-flex items-center gap-2 rounded-full bg-white px-3 py-1 text-xs font-semibold text-indigo-700 border border-indigo-200">
                                            <i data-lucide="map-pin" class="w-3 h-3"></i>
                                            {{ $emploi->salle ?? 'Non défini' }}
                                        </span>
                                    </div>
                                    <div class="mt-3 flex items-center gap-4">
                                        <div class="flex items-center gap-2 text-xs text-slate-600">
                                            <i data-lucide="calendar" class="w-3.5 h-3.5"></i>
                                            {{ $emploi->heure_debut ?? '—' }} - {{ $emploi->heure_fin ?? '—' }}
                                        </div>
                                        @if($emploi->semestre)
                                        <div class="flex items-center gap-2 text-xs text-slate-600">
                                            <i data-lucide="layers" class="w-3.5 h-3.5"></i>
                                            {{ $emploi->semestre->libelle }}
                                        </div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                    @endif
                @endforeach
            </div>
        </div>
    </div>
    @else
    <div class="rounded-2xl bg-white p-12 text-center border border-slate-200 shadow-md">
        <i data-lucide="calendar" class="mx-auto h-12 w-12 text-slate-300"></i>
        <h3 class="mt-4 text-lg font-semibold text-slate-900">Aucun emploi du temps</h3>
        <p class="mt-1 text-sm text-slate-600">Votre emploi du temps n'a pas encore été défini.</p>
    </div>
    @endif
</div>
@endsection
