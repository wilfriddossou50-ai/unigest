@extends('layouts.etudiant')

@section('title', 'Tableau de bord')
@section('subtitle', 'Bienvenue dans votre espace académique')

@section('content')
<div x-data="{ ready: false }" x-init="setTimeout(() => ready = true, 50)" class="space-y-6">
    <!-- HERO SECTION -->
    <div :class="ready ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'"
        class="rounded-2xl bg-gradient-to-br from-indigo-600 via-blue-600 to-cyan-500 p-8 text-white shadow-xl transition-all duration-700 ease-out overflow-hidden relative">
        
        <!-- Background pattern -->
        <div class="absolute inset-0 opacity-10">
            <div class="absolute -top-40 -right-40 w-80 h-80 bg-white rounded-full"></div>
            <div class="absolute -bottom-40 -left-40 w-80 h-80 bg-white rounded-full"></div>
        </div>

        <div class="relative z-10 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
                <p class="text-sm font-semibold uppercase tracking-widest text-white/75">Bienvenue</p>
                <h2 class="mt-2 text-4xl font-bold tracking-tight">{{ $user->prenom }},</h2>
                <p class="mt-3 max-w-2xl text-base text-white/90">Consultez vos notes, votre emploi du temps et gérez votre parcours académique.</p>
            </div>
            <div class="inline-flex items-center gap-3 rounded-full bg-white/20 backdrop-blur-md px-4 py-2.5 text-sm font-semibold text-white ring-1 ring-white/30">
                <span class="inline-flex h-2.5 w-2.5 rounded-full bg-emerald-300 animate-pulse"></span>
                Compte actif
            </div>
        </div>

        <!-- Stats -->
        <div class="relative z-10 mt-8 grid gap-4 sm:grid-cols-3">
            <div class="rounded-xl bg-white/10 backdrop-blur-md p-4 ring-1 ring-white/20 hover:bg-white/15 transition">
                <p class="text-xs uppercase tracking-widest text-white/70 font-semibold">Filière</p>
                <p class="mt-3 text-xl font-bold text-white">{{ $inscription?->filiere?->libelle ?? 'Non définie' }}</p>
            </div>
            <div class="rounded-xl bg-white/10 backdrop-blur-md p-4 ring-1 ring-white/20 hover:bg-white/15 transition">
                <p class="text-xs uppercase tracking-widest text-white/70 font-semibold">Niveau</p>
                <p class="mt-3 text-xl font-bold text-white">{{ $etudiant?->niveau?->libelle ?? 'Non défini' }}</p>
            </div>
            <div class="rounded-xl bg-white/10 backdrop-blur-md p-4 ring-1 ring-white/20 hover:bg-white/15 transition">
                <p class="text-xs uppercase tracking-widest text-white/70 font-semibold">MAJ</p>
                <p class="mt-3 text-xl font-bold text-white text-sm">{{ optional($inscription?->updated_at)->translatedFormat('d M Y') ?? 'N/A' }}</p>
            </div>
        </div>
    </div>

    <!-- QUICK ACCESS CARDS -->
    <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <a href="{{ route('etudiant.notes.index') }}"
            class="group relative overflow-hidden rounded-xl bg-white p-6 shadow-md ring-1 ring-slate-200 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:ring-indigo-200">
            <div class="absolute inset-0 bg-gradient-to-br from-indigo-500/0 to-indigo-500/0 group-hover:from-indigo-500/5 group-hover:to-indigo-500/10 transition-all"></div>
            <div class="relative">
                <div class="flex items-start justify-between mb-4">
                    <div>
                        <p class="text-sm font-semibold uppercase tracking-wider text-slate-500">Notes</p>
                        <p class="mt-1 text-2xl font-bold text-slate-900">Consulter</p>
                    </div>
                    <span class="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-indigo-100 text-indigo-600 shadow-sm">
                        <i data-lucide="file-text" class="w-5 h-5"></i>
                    </span>
                </div>
                <p class="text-sm text-slate-600">Accédez à vos notes semestrielles et suivez votre progression.</p>
            </div>
        </a>

        <a href="{{ route('etudiant.bulletin.index') }}"
            class="group relative overflow-hidden rounded-xl bg-white p-6 shadow-md ring-1 ring-slate-200 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:ring-blue-200">
            <div class="absolute inset-0 bg-gradient-to-br from-blue-500/0 to-blue-500/0 group-hover:from-blue-500/5 group-hover:to-blue-500/10 transition-all"></div>
            <div class="relative">
                <div class="flex items-start justify-between mb-4">
                    <div>
                        <p class="text-sm font-semibold uppercase tracking-wider text-slate-500">Bulletin</p>
                        <p class="mt-1 text-2xl font-bold text-slate-900">Télécharger</p>
                    </div>
                    <span class="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100 text-blue-600 shadow-sm">
                        <i data-lucide="download" class="w-5 h-5"></i>
                    </span>
                </div>
                <p class="text-sm text-slate-600">Téléchargez vos bulletins académiques officiels.</p>
            </div>
        </a>

        <a href="{{ route('etudiant.emploi.index') }}"
            class="group relative overflow-hidden rounded-xl bg-white p-6 shadow-md ring-1 ring-slate-200 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:ring-cyan-200">
            <div class="absolute inset-0 bg-gradient-to-br from-cyan-500/0 to-cyan-500/0 group-hover:from-cyan-500/5 group-hover:to-cyan-500/10 transition-all"></div>
            <div class="relative">
                <div class="flex items-start justify-between mb-4">
                    <div>
                        <p class="text-sm font-semibold uppercase tracking-wider text-slate-500">Emploi du temps</p>
                        <p class="mt-1 text-2xl font-bold text-slate-900">Voir</p>
                    </div>
                    <span class="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-cyan-100 text-cyan-600 shadow-sm">
                        <i data-lucide="calendar" class="w-5 h-5"></i>
                    </span>
                </div>
                <p class="text-sm text-slate-600">Consultez votre planning et vos séances de la semaine.</p>
            </div>
        </a>
    </div>

    <!-- DETAILED INFO SECTION -->
    <div class="grid gap-6 lg:grid-cols-2">
        <!-- DOSSIER -->
        <div :class="ready ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'"
            class="rounded-2xl bg-white p-6 shadow-md ring-1 ring-slate-200 transition-all duration-700 ease-out hover:shadow-lg hover:ring-slate-300">
            <div class="flex items-start justify-between gap-4 mb-6">
                <div>
                    <h3 class="text-lg font-semibold text-slate-900">Informations personnelles</h3>
                    <p class="mt-1 text-sm text-slate-600">Détails de votre compte</p>
                </div>
                <span class="inline-flex items-center rounded-lg bg-indigo-100 px-3 py-1.5 text-xs font-semibold text-indigo-700">
                    <i data-lucide="check-circle" class="w-3.5 h-3.5 mr-1"></i>
                    Actif
                </span>
            </div>
            <div class="space-y-3">
                <div class="rounded-lg bg-slate-50 p-4 border border-slate-200">
                    <dt class="text-xs font-semibold uppercase tracking-wider text-slate-500">Nom complet</dt>
                    <dd class="mt-1.5 text-base font-medium text-slate-900">{{ $user->nom }} {{ $user->prenom }}</dd>
                </div>
                <div class="rounded-lg bg-slate-50 p-4 border border-slate-200">
                    <dt class="text-xs font-semibold uppercase tracking-wider text-slate-500">Email</dt>
                    <dd class="mt-1.5 text-base font-medium text-slate-900 break-all">{{ $user->email }}</dd>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div class="rounded-lg bg-slate-50 p-4 border border-slate-200">
                        <dt class="text-xs font-semibold uppercase tracking-wider text-slate-500">Sexe</dt>
                        <dd class="mt-1.5 text-base font-medium text-slate-900">{{ $inscription->sexe === 'M' ? 'Masculin' : 'Féminin' }}</dd>
                    </div>
                    <div class="rounded-lg bg-slate-50 p-4 border border-slate-200">
                        <dt class="text-xs font-semibold uppercase tracking-wider text-slate-500">Naissance</dt>
                        <dd class="mt-1.5 text-base font-medium text-slate-900">{{ optional($inscription->date_naissance)->format('d/m/Y') ?? '—' }}</dd>
                    </div>
                </div>
            </div>
        </div>

        <!-- SUIVI ACADÉMIQUE -->
        <div :class="ready ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'"
            class="rounded-2xl bg-white p-6 shadow-md ring-1 ring-slate-200 transition-all duration-700 ease-out hover:shadow-lg hover:ring-slate-300">
            <div class="flex items-start justify-between gap-4 mb-6">
                <div>
                    <h3 class="text-lg font-semibold text-slate-900">État académique</h3>
                    <p class="mt-1 text-sm text-slate-600">Statut et accès</p>
                </div>
                <span class="inline-flex items-center rounded-lg bg-emerald-100 px-3 py-1.5 text-xs font-semibold text-emerald-700">
                    <i data-lucide="zap" class="w-3.5 h-3.5 mr-1"></i>
                    Optimal
                </span>
            </div>
            <ul class="space-y-3">
                <li class="flex gap-3 rounded-lg bg-emerald-50 p-4 border border-emerald-200">
                    <span class="flex-shrink-0 mt-0.5">
                        <span class="flex h-2 w-2 rounded-full bg-emerald-500"></span>
                    </span>
                    <span class="text-sm font-medium text-emerald-900">Notes et résultats disponibles</span>
                </li>
                <li class="flex gap-3 rounded-lg bg-blue-50 p-4 border border-blue-200">
                    <span class="flex-shrink-0 mt-0.5">
                        <span class="flex h-2 w-2 rounded-full bg-blue-500"></span>
                    </span>
                    <span class="text-sm font-medium text-blue-900">Informations de filière à jour</span>
                </li>
                <li class="flex gap-3 rounded-lg bg-indigo-50 p-4 border border-indigo-200">
                    <span class="flex-shrink-0 mt-0.5">
                        <span class="flex h-2 w-2 rounded-full bg-indigo-500"></span>
                    </span>
                    <span class="text-sm font-medium text-indigo-900">Accès complet aux documents</span>
                </li>
            </ul>
        </div>
    </div>
</div>
@endsection
