@extends('layouts.etudiant')

@section('title', 'Mon bulletin')
@section('subtitle', 'Consultez et téléchargez votre bulletin')

@section('content')
<div x-data="{ ready: false }" x-init="setTimeout(() => ready = true, 50)" class="space-y-6">
    <!-- HEADER -->
    <div :class="ready ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'"
        class="rounded-2xl bg-white p-6 border border-slate-200 shadow-md transition-all duration-700 ease-out">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-bold text-slate-900">Mon bulletin</h1>
                <p class="mt-1 text-sm text-slate-600">Votre bulletin académique officiel</p>
            </div>
            <a href="{{ route('etudiant.dashboard') }}" class="inline-flex items-center gap-2 rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100 transition">
                <i data-lucide="arrow-left" class="w-4 h-4"></i>
                Retour
            </a>
        </div>
    </div>

    @if($bulletinReady && $notes->isNotEmpty())
    <!-- RESUME -->
    <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <div class="rounded-xl bg-gradient-to-br from-emerald-50 to-emerald-100 p-6 border border-emerald-200">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs uppercase tracking-widest font-semibold text-emerald-600">Moyenne</p>
                    <p class="mt-2 text-3xl font-bold text-emerald-900">{{ $average ?? '—' }}</p>
                </div>
                <span class="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-emerald-200 text-emerald-700">
                    <i data-lucide="bar-chart" class="w-5 h-5"></i>
                </span>
            </div>
        </div>

        <div class="rounded-xl bg-gradient-to-br from-blue-50 to-blue-100 p-6 border border-blue-200">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs uppercase tracking-widest font-semibold text-blue-600">Statut</p>
                    <p class="mt-2 text-xl font-bold text-blue-900">
                        @if($average && $average >= 10)
                        <span class="text-emerald-600">Admis</span>
                        @else
                        <span class="text-amber-600">À suivre</span>
                        @endif
                    </p>
                </div>
                <span class="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-blue-200 text-blue-700">
                    <i data-lucide="check-circle" class="w-5 h-5"></i>
                </span>
            </div>
        </div>

        <div class="rounded-xl bg-gradient-to-br from-indigo-50 to-indigo-100 p-6 border border-indigo-200">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs uppercase tracking-widest font-semibold text-indigo-600">Notes</p>
                    <p class="mt-2 text-3xl font-bold text-indigo-900">{{ $notes->count() }}</p>
                </div>
                <span class="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-indigo-200 text-indigo-700">
                    <i data-lucide="file-text" class="w-5 h-5"></i>
                </span>
            </div>
        </div>
    </div>

    <!-- ACTION BUTTONS -->
    <div class="flex flex-col gap-3 sm:flex-row">
        <button onclick="window.print()" class="inline-flex items-center justify-center gap-2 rounded-lg bg-indigo-600 px-6 py-3 text-sm font-semibold text-white hover:bg-indigo-700 transition">
            <i data-lucide="printer" class="w-4 h-4"></i>
            Imprimer
        </button>
        <a href="#" class="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-300 px-6 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-100 transition">
            <i data-lucide="download" class="w-4 h-4"></i>
            Télécharger PDF
        </a>
    </div>

    <!-- BULLETIN TABLE -->
    <div class="rounded-2xl bg-white border border-slate-200 shadow-md overflow-hidden">
        <div class="px-6 py-5 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-slate-100">
            <h2 class="text-lg font-semibold text-slate-900">Détail des résultats</h2>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-200">
                <thead class="bg-slate-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-600">Matière</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-600">Module</th>
                        <th class="px-6 py-3 text-center text-xs font-semibold uppercase tracking-wider text-slate-600">Note</th>
                        <th class="px-6 py-3 text-center text-xs font-semibold uppercase tracking-wider text-slate-600">Crédits</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-200 bg-white">
                    @foreach($notes as $note)
                    <tr class="hover:bg-slate-50 transition">
                        <td class="px-6 py-4 font-medium text-slate-900">{{ $note->matiere?->libelle ?? '—' }}</td>
                        <td class="px-6 py-4 text-sm text-slate-600">{{ $note->matiere?->module?->nom ?? '—' }}</td>
                        <td class="px-6 py-4 text-center">
                            @if($note->note_finale)
                            <span class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-blue-100 text-sm font-bold text-blue-700">
                                {{ number_format($note->note_finale, 2, ',', '.') }}
                            </span>
                            @else
                            <span class="text-sm text-slate-500">—</span>
                            @endif
                        </td>
                        <td class="px-6 py-4 text-center">
                            <span class="text-sm font-semibold text-slate-900">{{ $note->matiere?->module?->credit ?? '—' }}</span>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    @else
    <div class="rounded-2xl bg-white p-12 text-center border border-slate-200 shadow-md">
        <i data-lucide="file-bar-chart" class="mx-auto h-12 w-12 text-slate-300"></i>
        <h3 class="mt-4 text-lg font-semibold text-slate-900">Bulletin non disponible</h3>
        <p class="mt-1 text-sm text-slate-600">Votre bulletin sera disponible une fois les notes saisies.</p>
    </div>
    @endif
</div>
@endsection
