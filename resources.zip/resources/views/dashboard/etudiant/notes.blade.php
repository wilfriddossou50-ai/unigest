@extends('layouts.etudiant')

@section('title', 'Mes notes')
@section('subtitle', 'Consultez votre performance académique')

@section('content')
<div x-data="{ ready: false }" x-init="setTimeout(() => ready = true, 50)" class="space-y-6">
    <!-- HEADER SECTION -->
    <div :class="ready ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'"
        class="rounded-2xl bg-white p-6 border border-slate-200 shadow-md transition-all duration-700 ease-out hover:shadow-lg hover:border-slate-300">
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
                <h1 class="text-2xl font-bold text-slate-900">Mes notes</h1>
                <p class="mt-1 text-sm text-slate-600">Vos résultats semestriels et performance globale</p>
            </div>
            <a href="{{ route('etudiant.dashboard') }}" class="inline-flex items-center gap-2 rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100 transition">
                <i data-lucide="arrow-left" class="w-4 h-4"></i>
                Retour
            </a>
        </div>
    </div>

    <!-- STATS CARDS -->
    <div class="grid gap-4 sm:grid-cols-3">
        <div class="rounded-xl bg-gradient-to-br from-blue-50 to-blue-100 p-5 border border-blue-200 shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs uppercase tracking-widest font-semibold text-blue-600">Semestre actuel</p>
                    <p class="mt-2 text-2xl font-bold text-blue-900">{{ $currentSemestre ?? 'Non défini' }}</p>
                </div>
                <span class="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-blue-200 text-blue-700">
                    <i data-lucide="calendar" class="w-5 h-5"></i>
                </span>
            </div>
        </div>

        <div class="rounded-xl bg-gradient-to-br from-emerald-50 to-emerald-100 p-5 border border-emerald-200 shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs uppercase tracking-widest font-semibold text-emerald-600">Moyenne générale</p>
                    <p class="mt-2 text-2xl font-bold text-emerald-900">{{ $average ?? '—' }}/20</p>
                </div>
                <span class="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-emerald-200 text-emerald-700">
                    <i data-lucide="trending-up" class="w-5 h-5"></i>
                </span>
            </div>
        </div>

        <div class="rounded-xl bg-gradient-to-br from-indigo-50 to-indigo-100 p-5 border border-indigo-200 shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs uppercase tracking-widest font-semibold text-indigo-600">Validés</p>
                    <p class="mt-2 text-2xl font-bold text-indigo-900">{{ $validatedCount ?? 0 }}</p>
                </div>
                <span class="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-indigo-200 text-indigo-700">
                    <i data-lucide="check-circle" class="w-5 h-5"></i>
                </span>
            </div>
        </div>
    </div>

    <!-- NOTES TABLE -->
    <div class="rounded-2xl bg-white border border-slate-200 shadow-md overflow-hidden">
        <div class="px-6 py-5 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-slate-100">
            <div class="flex items-center justify-between">
                <h2 class="text-lg font-semibold text-slate-900">Détail des notes</h2>
                @if($notes->isNotEmpty())
                <span class="inline-flex items-center rounded-full bg-blue-100 px-3 py-1 text-xs font-semibold text-blue-700">
                    <i data-lucide="info" class="w-3 h-3 mr-1.5"></i>
                    {{ $notes->count() }} résultats
                </span>
                @else
                <span class="inline-flex items-center rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-700">
                    <i data-lucide="alert-circle" class="w-3 h-3 mr-1.5"></i>
                    Aucune note
                </span>
                @endif
            </div>
        </div>

        @if($notes->isNotEmpty())
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-slate-200">
                <thead class="bg-slate-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-600">Matière</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-600">Module</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-slate-600">Semestre</th>
                        <th class="px-6 py-3 text-center text-xs font-semibold uppercase tracking-wider text-slate-600">Note</th>
                        <th class="px-6 py-3 text-center text-xs font-semibold uppercase tracking-wider text-slate-600">Statut</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-200 bg-white">
                    @foreach($notes as $note)
                    <tr class="hover:bg-slate-50 transition">
                        <td class="px-6 py-4">
                            <div>
                                <p class="font-medium text-slate-900">{{ $note->matiere?->libelle ?? '—' }}</p>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <span class="text-sm text-slate-600">{{ $note->matiere?->module?->nom ?? '—' }}</span>
                        </td>
                        <td class="px-6 py-4">
                            <span class="text-sm text-slate-600">{{ $note->matiere?->module?->semestre?->libelle ?? '—' }}</span>
                        </td>
                        <td class="px-6 py-4 text-center">
                            @if(! is_null($note->note_finale))
                            <span class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-blue-100 text-sm font-bold text-blue-700">
                                {{ number_format($note->note_finale, 2, ',', '.') }}
                            </span>
                            @else
                            <span class="text-sm text-slate-500">N/A</span>
                            @endif
                        </td>
                        <td class="px-6 py-4 text-center">
                            @if(in_array($note->statut, ['validee', 'rattrapage_valide', 'reprise_valide'], true))
                            <span class="inline-flex items-center gap-1.5 rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-700">
                                <span class="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
                                Validée
                            </span>
                            @else
                            <span class="inline-flex items-center gap-1.5 rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-700">
                                <span class="h-1.5 w-1.5 rounded-full bg-amber-500"></span>
                                {{ ucfirst($note->statut ?? 'En attente') }}
                            </span>
                            @endif
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        @else
        <div class="px-6 py-12 text-center">
            <i data-lucide="inbox" class="mx-auto h-12 w-12 text-slate-300"></i>
            <h3 class="mt-4 text-lg font-semibold text-slate-900">Aucun résultat</h3>
            <p class="mt-1 text-sm text-slate-600">Les notes seront affichées dès qu'elles seront saisies par l'administration.</p>
        </div>
        @endif
    </div>
</div>
@endsection
