@extends('layouts.admin')

@section('title', 'Tableau de bord')
@section('subtitle', 'Suivi rapide des inscriptions et de l’activité')

@section('content')
<div x-data="{ ready: false }" x-init="setTimeout(() => ready = true, 50)" class="space-y-6">
    <div class="grid gap-6 lg:grid-cols-3">
        <div :class="ready ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'"
            class="rounded-3xl bg-white p-6 border border-slate-200 shadow-sm transition-all duration-700 ease-out hover:-translate-y-1 hover:shadow-xl">
            <div class="flex items-center justify-between gap-4">
                <div>
                    <div class="text-sm font-semibold uppercase tracking-[0.25em] text-slate-400">En attente</div>
                    <div class="mt-4 text-4xl font-bold text-slate-900">{{ $pending }}</div>
                </div>
                <i data-lucide="clock" class="w-8 h-8 text-amber-500"></i>
            </div>
            <p class="mt-4 text-sm text-slate-500">Demandes d'inscription en attente de traitement.</p>
        </div>

        <div :class="ready ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'"
            class="rounded-3xl bg-white p-6 border border-slate-200 shadow-sm transition-all duration-700 ease-out hover:-translate-y-1 hover:shadow-xl">
            <div class="flex items-center justify-between gap-4">
                <div>
                    <div class="text-sm font-semibold uppercase tracking-[0.25em] text-slate-400">Approuvées</div>
                    <div class="mt-4 text-4xl font-bold text-slate-900">{{ $approved }}</div>
                </div>
                <i data-lucide="check-circle" class="w-8 h-8 text-emerald-500"></i>
            </div>
            <p class="mt-4 text-sm text-slate-500">Inscriptions validées et comptes étudiants activés.</p>
        </div>

        <div :class="ready ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'"
            class="rounded-3xl bg-white p-6 border border-slate-200 shadow-sm transition-all duration-700 ease-out hover:-translate-y-1 hover:shadow-xl">
            <div class="flex items-center justify-between gap-4">
                <div>
                    <div class="text-sm font-semibold uppercase tracking-[0.25em] text-slate-400">Refusées</div>
                    <div class="mt-4 text-4xl font-bold text-slate-900">{{ $rejected }}</div>
                </div>
                <i data-lucide="x-circle" class="w-8 h-8 text-rose-500"></i>
            </div>
            <p class="mt-4 text-sm text-slate-500">Demandes qui nécessitent une analyse ou correction.</p>
        </div>
    </div>

    <div :class="ready ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'"
        class="rounded-3xl bg-white p-6 border border-slate-200 shadow-sm transition-all duration-700 ease-out">
        <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-lg font-semibold text-slate-900">Dernières inscriptions</h2>
                <p class="text-sm text-slate-500">Consultez les dernières demandes de validation.</p>
            </div>
            <a href="{{ route('admin.inscriptions.index') }}"
                class="inline-flex items-center gap-2 text-sm font-semibold text-blue-700 hover:text-blue-900">
                Voir toutes
                <i data-lucide="arrow-right" class="w-4 h-4"></i>
            </a>
        </div>

        <div class="mt-6 space-y-4">
            @forelse($latest as $inscription)
            <a href="{{ route('admin.inscriptions.show', $inscription) }}"
                class="block rounded-3xl border border-slate-200 p-5 hover:border-blue-300 hover:bg-blue-50 transition duration-300">
                <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                        <h3 class="text-base font-semibold text-slate-900">{{ $inscription->nom }} {{ $inscription->prenom }}</h3>
                        <p class="text-sm text-slate-500">{{ $inscription->user->email }}</p>
                    </div>
                    <span class="rounded-full px-3 py-1 text-xs font-semibold {{ $inscription->statut === 'en_attente' ? 'bg-amber-100 text-amber-700' : ($inscription->statut === 'approuvee' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700') }}">
                        {{ ucwords(str_replace('_', ' ', $inscription->statut)) }}
                    </span>
                </div>
                <p class="mt-3 text-sm text-slate-500">Filière : {{ $inscription->filiere?->libelle ?? 'N/A' }}</p>
            </a>
            @empty
            <p class="text-sm text-slate-500">Aucune inscription récente.</p>
            @endforelse
        </div>
    </div>
</div>
@endsection