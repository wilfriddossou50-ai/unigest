@extends('layouts.public')

@section('content')

<section class="min-h-[80vh] flex items-center justify-center px-6">

    <div class="w-full max-w-md bg-white border rounded-2xl shadow-sm p-8">

        <h1 class="text-2xl font-bold text-center text-slate-900">
            Connexion
        </h1>

        <p class="text-center text-sm text-slate-500 mt-2">
            Accédez à votre espace universitaire
        </p>

        <form method="POST" action="{{ route('login') }}" class="mt-8 space-y-5">
            @csrf

            <div>
                <label class="text-sm text-slate-600">Email</label>
                <input type="email" name="email"
                    class="w-full mt-1 px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    value="{{ old('email') }}">
                @error('email')
                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="text-sm text-slate-600">Mot de passe</label>
                <input type="password" name="password"
                    class="w-full mt-1 px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none">
                @error('password')
                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <button type="submit"
                class="w-full bg-blue-700 text-white py-3 rounded-lg font-semibold hover:bg-blue-800">
                Se connecter
            </button>

        </form>

        <p class="text-center text-sm text-slate-500 mt-6">
            Pas de compte ?
            <a href="{{ route('register') }}" class="text-blue-700 hover:underline">
                S'inscrire
            </a>
        </p>

    </div>

</section>

@endsection