@extends('layouts.public')

@section('content')

<section class="min-h-[80vh] flex items-center justify-center px-6">

    <div class="w-full max-w-lg bg-white border rounded-2xl shadow-sm p-8">

        <h1 class="text-2xl font-bold text-center text-slate-900">
            Inscription Étudiant
        </h1>

        <p class="text-center text-sm text-slate-500 mt-2">
            Création de votre compte universitaire
        </p>

        <form method="POST" action="{{ route('register') }}" class="mt-8 space-y-5">
            @csrf

            <div class="grid grid-cols-2 gap-4">

                <div>
                    <label class="text-sm text-slate-600">Nom</label>
                    <input type="text" name="nom"
                        class="w-full mt-1 px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                        value="{{ old('nom') }}">
                    @error('nom')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label class="text-sm text-slate-600">Prénom</label>
                    <input type="text" name="prenom"
                        class="w-full mt-1 px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                        value="{{ old('prenom') }}">
                    @error('prenom')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

            </div>

            <div class="grid grid-cols-2 gap-4">

                <div>
                    <label class="text-sm text-slate-600">Sexe</label>
                    <select name="sexe"
                        class="w-full mt-1 px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none">
                        <option value="">Choisir</option>
                        <option value="M" {{ old('sexe') === 'M' ? 'selected' : '' }}>Masculin</option>
                        <option value="F" {{ old('sexe') === 'F' ? 'selected' : '' }}>Féminin</option>
                    </select>
                    @error('sexe')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label class="text-sm text-slate-600">Date de naissance</label>
                    <input type="date" name="date_naissance"
                        class="w-full mt-1 px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                        value="{{ old('date_naissance') }}">
                    @error('date_naissance')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

            </div>

            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="text-sm text-slate-600">Filière</label>
                    <select name="filiere_id" id="filiere-select"
                        class="w-full mt-1 px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none">
                        <option value="">Choisir une filière</option>
                        @foreach($filieres as $filiere)
                        <option value="{{ $filiere->id }}" {{ old('filiere_id') == $filiere->id ? 'selected' : '' }}>
                            {{ $filiere->libelle }}
                        </option>
                        @endforeach
                    </select>
                    @error('filiere_id')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label class="text-sm text-slate-600">Niveau</label>
                    <select name="niveau_id" id="niveau-select"
                        class="w-full mt-1 px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                        {{ old('filiere_id') ? '' : 'disabled' }}>
                        <option value="">{{ old('filiere_id') ? 'Choisir un niveau' : 'Sélectionnez d’abord une filière' }}</option>
                        @foreach($niveaux as $niveau)
                        <option value="{{ $niveau->id }}" {{ old('niveau_id') == $niveau->id ? 'selected' : '' }}>
                            {{ $niveau->libelle }}
                        </option>
                        @endforeach
                    </select>
                    @error('niveau_id')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <hr class="my-4">

            <div>
                <label class="text-sm text-slate-600">Email</label>
                <input type="email" name="email"
                    class="w-full mt-1 px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    value="{{ old('email') }}">
                @error('email')
                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="text-sm text-slate-600">Mot de passe</label>
                <input type="password" name="password"
                    class="w-full mt-1 px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none">
                @error('password')
                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label class="text-sm text-slate-600">Confirmation</label>
                <input type="password" name="password_confirmation"
                    class="w-full mt-1 px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none">
                @error('password_confirmation')
                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <button type="submit"
                class="w-full bg-blue-700 text-white py-3 rounded-lg font-semibold hover:bg-blue-800">
                Créer le compte étudiant
            </button>

        </form>

        <p class="text-center text-sm text-slate-500 mt-6">
            Déjà un compte ?
            <a href="{{ route('login') }}" class="text-blue-700 hover:underline">
                Se connecter
            </a>
        </p>

    </div>

</section>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const filiereSelect = document.querySelector('#filiere-select');
        const niveauSelect = document.querySelector('#niveau-select');

        if (!filiereSelect || !niveauSelect) {
            return;
        }

        function updateNiveauState() {
            if (filiereSelect.value === '') {
                niveauSelect.disabled = true;
                niveauSelect.querySelector('option[value=""]').textContent = 'Sélectionnez d’abord une filière';
            } else {
                niveauSelect.disabled = false;
                niveauSelect.querySelector('option[value=""]').textContent = 'Choisir un niveau';
            }
        }

        filiereSelect.addEventListener('change', updateNiveauState);
        updateNiveauState();
    });
</script>

@endsection