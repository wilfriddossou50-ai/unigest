@extends('layouts.professeur')

@section('title', 'Tableau de Bord - Professeur')

@section('content')
<div class="p-8">
    <!-- Welcome Header -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-slate-900">Bienvenue, {{ auth()->user()->name }}</h1>
        <p class="text-slate-600 mt-2">Gérez vos matières, vos étudiants et vos notes</p>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <!-- Matières -->
        <div class="bg-white rounded-xl shadow-sm p-6 border-l-4 border-emerald-600">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-slate-600 font-medium">Matières enseignées</p>
                    <p class="text-3xl font-bold text-slate-900 mt-2">{{ $matieres ?? 0 }}</p>
                </div>
                <div class="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center">
                    <i data-lucide="book" class="w-6 h-6 text-emerald-600"></i>
                </div>
            </div>
        </div>

        <!-- Étudiants -->
        <div class="bg-white rounded-xl shadow-sm p-6 border-l-4 border-blue-600">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-slate-600 font-medium">Étudiants</p>
                    <p class="text-3xl font-bold text-slate-900 mt-2">{{ $etudiants ?? 0 }}</p>
                </div>
                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i data-lucide="users" class="w-6 h-6 text-blue-600"></i>
                </div>
            </div>
        </div>

        <!-- Notes à Évaluer -->
        <div class="bg-white rounded-xl shadow-sm p-6 border-l-4 border-orange-600">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-slate-600 font-medium">Notes en attente</p>
                    <p class="text-3xl font-bold text-slate-900 mt-2">0</p>
                </div>
                <div class="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <i data-lucide="award" class="w-6 h-6 text-orange-600"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Content Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Mes Matières -->
        <div class="lg:col-span-2">
            <div class="bg-white rounded-xl shadow-sm p-6">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-lg font-bold text-slate-900">Mes Matières</h2>
                    <a href="#" class="text-emerald-600 hover:text-emerald-700 text-sm font-medium">Voir tout</a>
                </div>

                <div class="space-y-4">
                    @if(isset($recentNotes) && $recentNotes->count() > 0)
                    @foreach($recentNotes->take(5) as $matiere)
                    <div class="flex items-center justify-between p-4 border border-slate-200 rounded-lg hover:border-emerald-300 transition">
                        <div>
                            <h3 class="font-medium text-slate-900">{{ $matiere->nom }}</h3>
                            <p class="text-sm text-slate-500">Code: {{ $matiere->code }}</p>
                        </div>
                        <div class="text-right">
                            <p class="text-sm font-semibold text-slate-900">{{ $matiere->credit }} crédits</p>
                            <a href="#" class="text-emerald-600 hover:text-emerald-700 text-xs font-medium mt-1 inline-block">Gérer →</a>
                        </div>
                    </div>
                    @endforeach
                    @else
                    <div class="p-8 text-center text-slate-500">
                        <i data-lucide="inbox" class="w-12 h-12 mx-auto opacity-50 mb-2"></i>
                        <p>Aucune matière assignée</p>
                    </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="bg-white rounded-xl shadow-sm p-6">
            <h2 class="text-lg font-bold text-slate-900 mb-4">Actions rapides</h2>

            <div class="space-y-3">
                <a href="#" class="flex items-center gap-3 p-3 border border-slate-200 rounded-lg hover:border-emerald-300 hover:bg-emerald-50 transition">
                    <i data-lucide="plus" class="w-5 h-5 text-emerald-600"></i>
                    <span class="text-sm font-medium text-slate-900">Ajouter des notes</span>
                </a>

                <a href="#" class="flex items-center gap-3 p-3 border border-slate-200 rounded-lg hover:border-emerald-300 hover:bg-emerald-50 transition">
                    <i data-lucide="file-plus" class="w-5 h-5 text-blue-600"></i>
                    <span class="text-sm font-medium text-slate-900">Consulter l'emploi</span>
                </a>

                <a href="#" class="flex items-center gap-3 p-3 border border-slate-200 rounded-lg hover:border-emerald-300 hover:bg-emerald-50 transition">
                    <i data-lucide="message-circle" class="w-5 h-5 text-orange-600"></i>
                    <span class="text-sm font-medium text-slate-900">Messages</span>
                </a>

                <a href="#" class="flex items-center gap-3 p-3 border border-slate-200 rounded-lg hover:border-emerald-300 hover:bg-emerald-50 transition">
                    <i data-lucide="settings" class="w-5 h-5 text-slate-600"></i>
                    <span class="text-sm font-medium text-slate-900">Paramètres</span>
                </a>
            </div>
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="mt-8 bg-white rounded-xl shadow-sm p-6">
        <h2 class="text-lg font-bold text-slate-900 mb-4">Activité récente</h2>

        <div class="space-y-3 text-sm text-slate-600">
            <div class="flex items-center gap-3 pb-3 border-b border-slate-200">
                <div class="w-2 h-2 bg-emerald-600 rounded-full"></div>
                <p>Vous avez ajouté des notes pour <strong>Mathématiques</strong></p>
                <span class="text-xs text-slate-500 ml-auto">Il y a 2 jours</span>
            </div>
            <div class="flex items-center gap-3 pb-3 border-b border-slate-200">
                <div class="w-2 h-2 bg-blue-600 rounded-full"></div>
                <p><strong>15 étudiants</strong> ont consulté vos notes</p>
                <span class="text-xs text-slate-500 ml-auto">Il y a 5 jours</span>
            </div>
            <div class="flex items-center gap-3">
                <div class="w-2 h-2 bg-orange-600 rounded-full"></div>
                <p>Votre profil a été mis à jour</p>
                <span class="text-xs text-slate-500 ml-auto">Il y a 1 semaine</span>
            </div>
        </div>
    </div>
</div>

<script>
    lucide.createIcons();
</script>
@endsection