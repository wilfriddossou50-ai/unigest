﻿@extends('layouts.public')

@section('content')

<!-- HERO -->
<section class="bg-gradient-to-b from-blue-50 to-slate-50">
    <div class="max-w-6xl mx-auto px-6 py-28 text-center">

        <p class="text-sm tracking-widest text-blue-700 uppercase mb-4">
            Plateforme académique numérique
        </p>

        <h1 class="text-4xl md:text-5xl font-bold leading-tight">
            Système de gestion académique pour établissements universitaires
        </h1>

        <p class="mt-6 text-lg text-slate-600 max-w-2xl mx-auto">
            Administration des étudiants, gestion des notes, organisation pédagogique et suivi des parcours académiques.
        </p>

        <div class="mt-10 flex justify-center gap-4">
            <a href="{{ route('login') }}"
                class="px-6 py-3 rounded-lg border border-slate-300 hover:bg-white">
                Se connecter
            </a>

            <a href="{{ route('register') }}"
                class="px-6 py-3 rounded-lg bg-blue-700 text-white hover:bg-blue-800">
                Accéder au système
            </a>
        </div>

    </div>
</section>

<!-- FEATURES -->
<section id="features" class="max-w-7xl mx-auto px-6 py-20">

    <div class="grid md:grid-cols-3 gap-8">

        <div class="bg-white p-8 rounded-xl border">
            <h3 class="text-lg font-semibold text-slate-900 mb-3">
                Gestion des étudiants
            </h3>
            <p class="text-slate-600 text-sm">
                Création, suivi et organisation des dossiers étudiants au sein des filières.
            </p>
        </div>

        <div class="bg-white p-8 rounded-xl border">
            <h3 class="text-lg font-semibold text-slate-900 mb-3">
                Évaluation académique
            </h3>
            <p class="text-slate-600 text-sm">
                Saisie des notes, calcul des moyennes et validation des résultats.
            </p>
        </div>

        <div class="bg-white p-8 rounded-xl border">
            <h3 class="text-lg font-semibold text-slate-900 mb-3">
                Organisation pédagogique
            </h3>
            <p class="text-slate-600 text-sm">
                Structuration des filières, semestres, modules et matières.
            </p>
        </div>

    </div>
</section>

<!-- ROLES -->
<section id="roles" class="bg-white border-y py-20">

    <div class="max-w-5xl mx-auto px-6 text-center">

        <h2 class="text-2xl font-semibold mb-12">
            Accès au système
        </h2>

        <div class="grid md:grid-cols-2 gap-8">

            <div class="p-8 border rounded-xl bg-slate-50">
                <h3 class="text-lg font-semibold mb-2">Administrateur</h3>
                <p class="text-sm text-slate-600">
                    Gestion complète des utilisateurs, des structures académiques et des évaluations.
                </p>
            </div>

            <div class="p-8 border rounded-xl bg-slate-50">
                <h3 class="text-lg font-semibold mb-2">Étudiant</h3>
                <p class="text-sm text-slate-600">
                    Consultation des notes, bulletins et suivi du parcours académique.
                </p>
            </div>

        </div>

    </div>
</section>

<!-- CTA -->
<section class="py-20 bg-blue-700 text-white text-center">

    <h2 class="text-3xl font-bold">
        Accédez à la plateforme académique
    </h2>

    <p class="mt-4 text-blue-100">
        Une gestion centralisée et structurée des activités universitaires
    </p>

    <a href="{{ route('register') }}"
        class="mt-8 inline-block px-8 py-3 bg-white text-blue-700 font-semibold rounded-lg">
        Commencer
    </a>

</section>

@endsection