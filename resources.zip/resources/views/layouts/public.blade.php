<!DOCTYPE html>
<html lang="fr" class="scroll-smooth">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name', 'UniGest') }}</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body class="bg-slate-50 text-slate-900">

    <!-- NAVBAR -->
    <header class="bg-white border-b">
        <div class="max-w-7xl mx-auto flex items-center justify-between px-6 py-5">

            <!-- LOGO -->
            <div class="text-xl font-semibold text-blue-700">
                UniGest
            </div>

            <!-- MENU -->
            <nav class="hidden md:flex gap-8 text-sm text-slate-600">
                <a href="/" class="hover:text-blue-700">Accueil</a>
                <a href="#features" class="hover:text-blue-700">Aperçu</a>
                <a href="#roles" class="hover:text-blue-700">Utilisateurs</a>
            </nav>

            <!-- ACTIONS -->
            <div class="flex gap-3">
                <a href="{{ route('login') }}"
                    class="px-4 py-2 text-sm rounded-lg border border-slate-200 hover:bg-slate-100">
                    Connexion
                </a>

                <a href="{{ route('register') }}"
                    class="px-4 py-2 text-sm rounded-lg bg-blue-700 text-white hover:bg-blue-800">
                    Inscription
                </a>
            </div>

        </div>
    </header>

    <!-- CONTENT -->
    <main>
        @yield('content')
    </main>

    <!-- FOOTER -->
    <footer class="bg-slate-950 text-slate-400 py-10 text-center text-sm mt-16">
        UniGest — Système de gestion universitaire © {{ date('Y') }}
    </footer>

</body>

</html>