<!DOCTYPE html>
<html lang="fr" class="scroll-smooth" x-data="{ sidebarOpen: false }">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name', 'UniGest') }} | @yield('title', 'Mon espace')</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        /* Custom scrollbar */
        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
        }

        .custom-scrollbar::-webkit-scrollbar-track {
            background: transparent;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: rgba(100, 116, 139, 0.4);
            border-radius: 3px;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: rgba(100, 116, 139, 0.6);
        }

        /* Smooth gradient text */
        .gradient-text {
            background: linear-gradient(135deg, #6366f1 0%, #3b82f6 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
    </style>
</head>

<body class="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 text-slate-900">

    <div class="min-h-screen lg:flex">

        <!-- OVERLAY MOBILE -->
        <div
            x-show="sidebarOpen"
            x-transition.opacity
            @click="sidebarOpen = false"
            class="fixed inset-0 bg-black/40 backdrop-blur-sm z-20 lg:hidden">
        </div>

        <!-- SIDEBAR -->
        <aside
            :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'"
            class="fixed lg:static lg:translate-x-0 z-30 transition-all duration-300 ease-out
                 w-72 h-screen lg:h-auto overflow-y-auto custom-scrollbar 
                 bg-gradient-to-b from-slate-900 via-slate-800 to-slate-950 
                 text-slate-100 flex flex-col shadow-2xl lg:shadow-none">

            <!-- BRAND -->
            <div class="flex-shrink-0 px-6 py-6 border-b border-slate-700/40">
                <a href="{{ route('etudiant.dashboard') }}" class="flex items-center gap-3 group">
                    <div class="w-12 h-12 bg-gradient-to-br from-indigo-500 via-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center shrink-0 shadow-lg group-hover:shadow-indigo-500/50 group-hover:shadow-xl transition-all duration-300">
                        <i data-lucide="graduation-cap" class="w-6 h-6 text-white"></i>
                    </div>
                    <div>
                        <h1 class="text-xl font-bold tracking-tight gradient-text">UniGest</h1>
                        <p class="text-xs text-slate-400">Espace Étudiant</p>
                    </div>
                </a>
            </div>

            <!-- INFOS ETUDIANT CARD -->
            @php
            $etudiant = auth()->user()->etudiant;
            $hasNotes = Route::has('etudiant.notes.index');
            $hasBulletin = Route::has('etudiant.bulletin.index');
            $hasModules = Route::has('etudiant.modules.index');
            $hasMatieres = Route::has('etudiant.matieres.index');
            $hasDettes = Route::has('etudiant.dettes.index');
            $hasEmploi = Route::has('etudiant.emploi.index');
            $hasProfil = Route::has('etudiant.profil.index');
            @endphp
            @if($etudiant)
            <div class="mx-4 mt-6 px-4 py-4 bg-gradient-to-br from-slate-700/50 to-slate-800/40 
                       hover:from-slate-700/70 hover:to-slate-800/60
                       rounded-2xl text-xs space-y-2 border border-slate-700/50 
                       transition-all duration-300 hover:border-slate-600/50">
                <div class="flex items-start justify-between">
                    <div>
                        <p class="text-slate-200 font-semibold text-sm">{{ $etudiant->numero_etudiant }}</p>
                        <p class="text-slate-400 text-[11px] mt-1 line-clamp-2">{{ $etudiant->filiere->libelle ?? '—' }}</p>
                    </div>
                    <span class="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-300">
                        <i data-lucide="zap" class="w-4 h-4"></i>
                    </span>
                </div>
                <div class="pt-2 border-t border-slate-700/40">
                    <p class="text-slate-400 text-[10px]">Niveau: <span class="text-slate-300 font-semibold">{{ $etudiant->niveau->nom ?? '—' }}</span></p>
                </div>
            </div>
            @endif

            <!-- NAV -->
            <nav class="flex-1 px-3 py-6 space-y-2 text-sm overflow-y-auto custom-scrollbar"
                x-data="{ openParcours: {{ request()->routeIs('etudiant.modules.*') || request()->routeIs('etudiant.matieres.*') ? 'true' : 'false' }}, 
                         openResultats: {{ request()->routeIs('etudiant.notes.*') || request()->routeIs('etudiant.bulletin.*') || request()->routeIs('etudiant.dettes.*') ? 'true' : 'false' }} }">

                <!-- Tableau de bord -->
                <div>
                    <a href="{{ route('etudiant.dashboard') }}"
                        class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 
                               {{ request()->routeIs('etudiant.dashboard') 
                                   ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white shadow-lg shadow-indigo-500/30' 
                                   : 'text-slate-300 hover:bg-slate-700/50 hover:text-white' }}">
                        <i data-lucide="layout-dashboard" class="w-5 h-5 shrink-0"></i>
                        <span class="font-medium">Tableau de bord</span>
                    </a>
                </div>

                <!-- Section Separator -->
                <div class="py-2 px-4 mt-2">
                    <p class="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Académique</p>
                </div>

                <!-- Mon parcours -->
                <div>
                    <button type="button"
                        @click="openParcours = !openParcours"
                        class="w-full flex items-center justify-between gap-3 px-4 py-3 rounded-xl transition-all duration-200 text-left 
                               {{ request()->routeIs('etudiant.modules.*') || request()->routeIs('etudiant.matieres.*') 
                                   ? 'bg-slate-700/50 text-white' 
                                   : 'text-slate-300 hover:bg-slate-700/30 hover:text-white' }}">
                        <span class="flex items-center gap-3">
                            <i data-lucide="book-open" class="w-5 h-5 shrink-0"></i>
                            <span class="font-medium">Mon parcours</span>
                        </span>
                        <i data-lucide="chevron-down" class="w-4 h-4 transition-transform duration-200" :class="openParcours && 'rotate-180'"></i>
                    </button>
                    <div x-show="openParcours" x-transition.origin.top class="mt-2 space-y-1 pl-3">
                        @if($hasModules)
                        <a href="{{ route('etudiant.modules.index') }}"
                            class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-slate-300 hover:bg-slate-700/40 hover:text-white 
                                   transition-all border-l-2 duration-200
                                   {{ request()->routeIs('etudiant.modules.*') ? 'bg-slate-700/40 text-white border-indigo-500' : 'border-transparent hover:border-indigo-500/50' }}">
                            <i data-lucide="package" class="w-4 h-4"></i>
                            <span class="text-sm">Mes modules</span>
                        </a>
                        @else
                        <span class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-slate-500 bg-slate-800/30 opacity-60">
                            <i data-lucide="package" class="w-4 h-4"></i>
                            <span class="text-sm">Mes modules</span>
                        </span>
                        @endif

                        @if($hasMatieres)
                        <a href="{{ route('etudiant.matieres.index') }}"
                            class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-slate-300 hover:bg-slate-700/40 hover:text-white 
                                   transition-all border-l-2 duration-200
                                   {{ request()->routeIs('etudiant.matieres.*') ? 'bg-slate-700/40 text-white border-indigo-500' : 'border-transparent hover:border-indigo-500/50' }}">
                            <i data-lucide="layers" class="w-4 h-4"></i>
                            <span class="text-sm">Matières</span>
                        </a>
                        @else
                        <span class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-slate-500 bg-slate-800/30 opacity-60">
                            <i data-lucide="layers" class="w-4 h-4"></i>
                            <span class="text-sm">Matières</span>
                        </span>
                        @endif
                    </div>
                </div>

                <!-- Résultats -->
                <div>
                    <button type="button"
                        @click="openResultats = !openResultats"
                        class="w-full flex items-center justify-between gap-3 px-4 py-3 rounded-xl transition-all duration-200 text-left 
                               {{ request()->routeIs('etudiant.notes.*') || request()->routeIs('etudiant.bulletin.*') || request()->routeIs('etudiant.dettes.*') 
                                   ? 'bg-slate-700/50 text-white' 
                                   : 'text-slate-300 hover:bg-slate-700/30 hover:text-white' }}">
                        <span class="flex items-center gap-3">
                            <i data-lucide="bar-chart-2" class="w-5 h-5 shrink-0"></i>
                            <span class="font-medium">Résultats</span>
                        </span>
                        <i data-lucide="chevron-down" class="w-4 h-4 transition-transform duration-200" :class="openResultats && 'rotate-180'"></i>
                    </button>
                    <div x-show="openResultats" x-transition.origin.top class="mt-2 space-y-1 pl-3">
                        @if($hasNotes)
                        <a href="{{ route('etudiant.notes.index') }}"
                            class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-slate-300 hover:bg-slate-700/40 hover:text-white 
                                   transition-all border-l-2 duration-200
                                   {{ request()->routeIs('etudiant.notes.*') ? 'bg-slate-700/40 text-white border-indigo-500' : 'border-transparent hover:border-indigo-500/50' }}">
                            <i data-lucide="file-text" class="w-4 h-4"></i>
                            <span class="text-sm">Mes notes</span>
                        </a>
                        @else
                        <span class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-slate-500 bg-slate-800/30 opacity-60">
                            <i data-lucide="file-text" class="w-4 h-4"></i>
                            <span class="text-sm">Mes notes</span>
                        </span>
                        @endif

                        @if($hasBulletin)
                        <a href="{{ route('etudiant.bulletin.index') }}"
                            class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-slate-300 hover:bg-slate-700/40 hover:text-white 
                                   transition-all border-l-2 duration-200
                                   {{ request()->routeIs('etudiant.bulletin.*') ? 'bg-slate-700/40 text-white border-indigo-500' : 'border-transparent hover:border-indigo-500/50' }}">
                            <i data-lucide="file-bar-chart" class="w-4 h-4"></i>
                            <span class="text-sm">Bulletin</span>
                        </a>
                        @else
                        <span class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-slate-500 bg-slate-800/30 opacity-60">
                            <i data-lucide="file-bar-chart" class="w-4 h-4"></i>
                            <span class="text-sm">Bulletin</span>
                        </span>
                        @endif

                        @if($hasDettes)
                        <a href="{{ route('etudiant.dettes.index') }}"
                            class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-slate-300 hover:bg-slate-700/40 hover:text-white 
                                   transition-all border-l-2 duration-200
                                   {{ request()->routeIs('etudiant.dettes.*') ? 'bg-slate-700/40 text-white border-indigo-500' : 'border-transparent hover:border-indigo-500/50' }}">
                            <i data-lucide="alert-circle" class="w-4 h-4"></i>
                            <span class="text-sm">Dettes</span>
                        </a>
                        @else
                        <span class="flex items-center gap-3 px-4 py-2.5 rounded-lg text-slate-500 bg-slate-800/30 opacity-60">
                            <i data-lucide="alert-circle" class="w-4 h-4"></i>
                            <span class="text-sm">Dettes</span>
                        </span>
                        @endif
                    </div>
                </div>

                <!-- Section Separator -->
                <div class="py-2 px-4 mt-2">
                    <p class="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Autres</p>
                </div>

                <!-- Planning -->
                @if($hasEmploi)
                <a href="{{ route('etudiant.emploi.index') }}"
                    class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 
                           {{ request()->routeIs('etudiant.emploi.*') 
                               ? 'bg-slate-700/50 text-white' 
                               : 'text-slate-300 hover:bg-slate-700/30 hover:text-white' }}">
                    <i data-lucide="calendar" class="w-5 h-5 shrink-0"></i>
                    <span class="font-medium">Emploi du temps</span>
                </a>
                @else
                <span class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-500 bg-slate-800/30 opacity-60">
                    <i data-lucide="calendar" class="w-5 h-5 shrink-0"></i>
                    <span class="font-medium">Emploi du temps</span>
                </span>
                @endif

                <!-- Profil -->
                @if($hasProfil)
                <a href="{{ route('etudiant.profil.index') }}"
                    class="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 
                           {{ request()->routeIs('etudiant.profil.*') 
                               ? 'bg-slate-700/50 text-white' 
                               : 'text-slate-300 hover:bg-slate-700/30 hover:text-white' }}">
                    <i data-lucide="user-cog" class="w-5 h-5 shrink-0"></i>
                    <span class="font-medium">Mon profil</span>
                </a>
                @else
                <span class="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-500 bg-slate-800/30 opacity-60">
                    <i data-lucide="user-cog" class="w-5 h-5 shrink-0"></i>
                    <span class="font-medium">Mon profil</span>
                </span>
                @endif

            </nav>

            <!-- FOOTER SIDEBAR -->
            <div class="px-4 py-5 border-t border-slate-700/40">
                <div class="flex items-center gap-3 mb-4">
                    <div class="w-10 h-10 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0 shadow-md">
                        {{ strtoupper(substr(auth()->user()->nom ?? 'E', 0, 1)) }}
                    </div>
                    <div class="text-xs overflow-hidden flex-1 min-w-0">
                        <p class="font-medium text-white truncate">{{ auth()->user()->nom }}</p>
                        <p class="text-slate-400 truncate">{{ auth()->user()->prenom }}</p>
                    </div>
                </div>
                <form method="POST" action="{{ route('logout') }}" class="w-full">
                    @csrf
                    <button class="w-full flex items-center justify-center gap-2 bg-slate-700/50 hover:bg-red-600/80 
                                  transition-all duration-200 py-2.5 rounded-lg text-sm text-slate-200 hover:text-white font-medium">
                        <i data-lucide="log-out" class="w-4 h-4"></i>
                        Déconnexion
                    </button>
                </form>
            </div>

        </aside>

        <!-- MAIN AREA -->
        <div class="flex-1 flex flex-col min-w-0">

            <!-- TOP BAR -->
            <header class="sticky top-0 z-10 bg-white/80 backdrop-blur-xl border-b border-slate-200/50 
                          px-4 lg:px-6 py-3 flex items-center justify-between gap-4 shadow-sm">

                <button @click="sidebarOpen = !sidebarOpen" class="lg:hidden p-2 rounded-lg hover:bg-slate-100 transition">
                    <i data-lucide="menu" class="w-5 h-5"></i>
                </button>

                <div class="min-w-0 flex-1">
                    <h2 class="text-base font-semibold truncate text-slate-900">@yield('title', 'Mon espace')</h2>
                    <p class="text-xs text-slate-500 hidden sm:block mt-0.5">@yield('subtitle', '')</p>
                </div>

                <div class="flex items-center gap-3 shrink-0">
                    <div class="w-9 h-9 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-md">
                        {{ strtoupper(substr(auth()->user()->nom ?? 'E', 0, 1)) }}
                    </div>
                    <span class="text-sm font-medium hidden sm:block text-slate-900">{{ auth()->user()->nom }}</span>
                </div>

            </header>

            <!-- FLASH MESSAGES -->
            <div class="px-4 lg:px-6 pt-4 space-y-3 max-w-full">
                @if(session('success'))
                <div class="flex items-start gap-3 rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-3 text-sm text-emerald-700 animate-in fade-in slide-in-from-top-2">
                    <i data-lucide="check-circle" class="w-4 h-4 mt-0.5 shrink-0"></i>
                    <div>{{ session('success') }}</div>
                </div>
                @endif
                @if(session('error'))
                <div class="flex items-start gap-3 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700 animate-in fade-in slide-in-from-top-2">
                    <i data-lucide="x-circle" class="w-4 h-4 mt-0.5 shrink-0"></i>
                    <div>{{ session('error') }}</div>
                </div>
                @endif
                @if(session('warning'))
                <div class="flex items-start gap-3 rounded-xl bg-amber-50 border border-amber-200 px-4 py-3 text-sm text-amber-700 animate-in fade-in slide-in-from-top-2">
                    <i data-lucide="alert-triangle" class="w-4 h-4 mt-0.5 shrink-0"></i>
                    <div>{{ session('warning') }}</div>
                </div>
                @endif
                @if($errors->any())
                <div class="flex items-start gap-3 rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700 animate-in fade-in slide-in-from-top-2">
                    <i data-lucide="x-circle" class="w-4 h-4 mt-0.5 shrink-0"></i>
                    <ul class="list-disc list-inside space-y-0.5">
                        @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
                @endif
            </div>

            <!-- CONTENT -->
            <main class="flex-1 px-4 lg:px-6 py-6 overflow-y-auto">
                @yield('content')
            </main>

            <!-- FOOTER -->
            <footer class="flex-shrink-0 px-6 py-3 border-t border-slate-200/50 text-xs text-slate-400 text-center bg-white/50">
                UniGest &copy; {{ date('Y') }} — Système de gestion universitaire
            </footer>

        </div>

    </div>

    <script>
        lucide.createIcons();
    </script>

</body>

</html>