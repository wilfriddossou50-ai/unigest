<?php

namespace App\Http\Controllers;

use App\Models\Note;
use App\Models\Etudiant;
use App\Models\Matiere;
use App\Services\NoteService;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class NoteController extends Controller
{
    protected $service;

    public function __construct(NoteService $service)
    {
        $this->service = $service;
    }

    public function index(Request $request)
    {
        $notes = Note::with(['etudiant.user', 'etudiant.filiere', 'etudiant.niveau', 'matiere.module.filiere', 'matiere.module.semestre'])
            ->when($request->filled('matiere_id'), fn($query) => $query->where('matiere_id', $request->matiere_id))
            ->when($request->filled('etudiant_id'), fn($query) => $query->where('etudiant_id', $request->etudiant_id))
            ->when($request->filled('semestre_id'), function ($query) use ($request) {
                $query->whereHas('matiere.module', fn($moduleQuery) => $moduleQuery->where('semestre_id', $request->semestre_id));
            })
            ->latest()
            ->paginate(10)
            ->withQueryString();

        $etudiants = Etudiant::with(['user', 'filiere', 'niveau'])->orderBy('numero_etudiant')->get();
        $matieres = Matiere::with('module.semestre')->orderBy('libelle')->get();
        $semestres = \App\Models\Semestre::orderBy('libelle')->get();

        return view('admin.notes.index', compact('notes', 'etudiants', 'matieres', 'semestres'));
    }

    public function create()
    {
        $etudiants = Etudiant::with(['user', 'filiere', 'niveau'])->orderBy('numero_etudiant')->get();
        $matieres = Matiere::with(['module.filiere', 'module.semestre'])->orderBy('libelle')->get();

        return view('admin.notes.create', compact('etudiants', 'matieres'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'etudiant_id' => 'required|exists:etudiants,id',
            'matiere_id' => [
                'required',
                'exists:matieres,id',
                Rule::unique('notes')->where(fn($query) => $query->where('etudiant_id', $request->etudiant_id)),
            ],
            'cc' => 'required|numeric|min:0|max:20',
            'examen' => 'required|numeric|min:0|max:20',
        ]);

        $etudiant = Etudiant::findOrFail($request->etudiant_id);
        $matiere = Matiere::with('module')->findOrFail($request->matiere_id);

        if ($etudiant->filiere_id !== $matiere->module?->filiere_id) {
            throw ValidationException::withMessages([
                'matiere_id' => "Cette matière n'appartient pas à la filière de l'étudiant sélectionné.",
            ]);
        }

        // 1. calcul note
        $note = $this->service->calculer(
            $request->cc,
            $request->examen
        );

        // 2. statut initial
        $statut = $this->service->statut($note);

        Note::create([
            'etudiant_id' => $request->etudiant_id,
            'matiere_id' => $request->matiere_id,
            'cc' => $request->cc,
            'examen' => $request->examen,
            'note_calculee' => $note,
            'note_finale' => $note,
            'statut' => $statut,
        ]);

        return redirect()->route('admin.notes.index')
            ->with('success', 'Note enregistrée');
    }

    /**
     * RATTRAPAGE
     */
    public function rattrapage(Request $request, Note $note)
    {
        $request->validate([
            'note_rattrapage' => 'required|numeric|min:0|max:20',
        ]);

        $result = $this->service->appliquerRattrapage(
            $request->note_rattrapage
        );

        $data = [
            'rattrapage' => $request->note_rattrapage,
            'statut' => $result['statut'],
        ];

        if (! is_null($result['note_finale'])) {
            $data['note_finale'] = $result['note_finale'];
        }

        $note->update($data);

        return back()->with('success', 'Rattrapage traité');
    }

    /**
     * REPRISE
     */
    public function reprise(Request $request, Note $note)
    {
        $request->validate([
            'note_reprise' => 'required|numeric|min:0|max:20',
        ]);

        $result = $this->service->appliquerReprise(
            $request->note_reprise
        );

        $data = [
            'reprise' => $request->note_reprise,
            'statut' => $result['statut'],
        ];

        if (! is_null($result['note_finale'])) {
            $data['note_finale'] = $result['note_finale'];
        }

        $note->update($data);

        return back()->with('success', 'Reprise traitée');
    }
}
