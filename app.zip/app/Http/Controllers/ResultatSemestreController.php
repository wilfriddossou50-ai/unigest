<?php

namespace App\Http\Controllers;

use App\Models\ResultatSemestre;
use App\Models\Etudiant;
use App\Models\Semestre;
use App\Services\ResultatSemestreService;

use Illuminate\Http\Request;

class ResultatSemestreController extends Controller
{
    protected $service;

    public function __construct(ResultatSemestreService $service)
    {
        $this->service = $service;
    }

    public function index()
    {
        $resultats = ResultatSemestre::with(['etudiant', 'semestre'])
            ->latest()
            ->paginate(10);

        return view('admin.resultats_semestre.index', compact('resultats'));
    }

    public function calculer(Etudiant $etudiant, Semestre $semestre)
    {
        $moyenne = $this->service->calculerMoyenne(
            $etudiant->id,
            $semestre->id
        );

        $decision = $this->service->decision($moyenne);

        ResultatSemestre::updateOrCreate(
            [
                'etudiant_id' => $etudiant->id,
                'semestre_id' => $semestre->id,
            ],
            [
                'moyenne' => $moyenne,
                'decision' => $decision,
            ]
        );

        return back()->with('success', 'Résultat semestre calculé');
    }
}
