<?php

namespace App\Http\Controllers;

use App\Models\ProgressionEtudiant;
use App\Models\Etudiant;
use App\Models\Niveau;
use App\Services\ProgressionService;

use Illuminate\Http\Request;

class ProgressionEtudiantController extends Controller
{
    protected $service;

    public function __construct(ProgressionService $service)
    {
        $this->service = $service;
    }

    public function index()
    {
        $progressions = ProgressionEtudiant::with(['etudiant', 'niveau'])
            ->latest()
            ->paginate(10);

        return view('admin.progression.index', compact('progressions'));
    }

    public function calculer(Etudiant $etudiant, Niveau $niveau, $decisionSemestre)
    {
        $statut = $this->service->determinerStatut($decisionSemestre);

        $diplome = $this->service->verifierDiplome(
            $niveau->code,
            $decisionSemestre
        );

        ProgressionEtudiant::updateOrCreate(
            [
                'etudiant_id' => $etudiant->id,
                'annee_academique' => date('Y'),
            ],
            [
                'niveau_id' => $niveau->id,
                'statut' => $diplome ?? $statut,
            ]
        );

        return back()->with('success', 'Progression mise à jour');
    }
}
