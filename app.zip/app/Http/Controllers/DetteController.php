<?php

namespace App\Http\Controllers;

use App\Models\Dette;
use App\Models\Etudiant;
use App\Services\DetteService;

use Illuminate\Http\Request;

class DetteController extends Controller
{
    protected $service;

    public function __construct(DetteService $service)
    {
        $this->service = $service;
    }

    /**
     * LISTE DES DETTES
     */
    public function index()
    {
        $dettes = Dette::with(['etudiant', 'matiere', 'module', 'semestre'])
            ->where('statut', 'en_cours')
            ->latest()
            ->paginate(10);

        $levees = Dette::where('statut', 'levee')->count();

        return view('admin.dettes.index', compact('dettes', 'levees'));
    }

    /**
     * DETTES D'UN ETUDIANT
     */
    public function etudiant(Etudiant $etudiant)
    {
        $dettes = Dette::with(['matiere', 'module', 'semestre'])
            ->where('etudiant_id', $etudiant->id)
            ->get();

        return view('admin.dettes.etudiant', compact('etudiant', 'dettes'));
    }

    /**
     * LEVER UNE DETTE MANUELLEMENT (ADMIN)
     */
    public function lever(Dette $dette)
    {
        $this->service->leverDette($dette);

        return back()->with('success', 'Dette levée avec succès');
    }

    /**
     * SUPPRESSION (cas exceptionnel)
     */
    public function destroy(Dette $dette)
    {
        $dette->delete();

        return back()->with('success', 'Dette supprimée');
    }
}
