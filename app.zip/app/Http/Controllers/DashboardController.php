<?php

namespace App\Http\Controllers;

use App\Models\Dette;
use App\Models\EmploiDuTemps;
use App\Models\Etudiant;
use App\Models\Inscription;
use App\Models\Matiere;
use App\Models\Note;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\View\View;

class DashboardController extends Controller
{
    /**
     * Show the dashboard based on user role.
     */
    public function adminDashboard(): View
    {
        $user = Auth::user();

        $pending = Inscription::where('statut', 'en_attente')->count();
        $approved = Inscription::where('statut', 'approuvee')->count();
        $rejected = Inscription::where('statut', 'refusee')->count();
        $latest = Inscription::with(['user', 'filiere'])->latest()->limit(5)->get();

        return view('dashboard.admin.index', compact('user', 'pending', 'approved', 'rejected', 'latest'));
    }

    /**
     * Return the current student profile for the authenticated user.
     */
    protected function getStudentEtudiant(): ?Etudiant
    {
        /** @var \App\Models\User|null $user */
        $user = Auth::user();

        return $user ? $user->etudiant()->with(['filiere', 'niveau'])->first() : null;
    }

    /**
     * Show the student dashboard.
     */
    public function etudiantDashboard(): RedirectResponse|View
    {
        /** @var \App\Models\User $user */
        $user = Auth::user();
        $inscription = $user->inscriptions()->with('filiere')->latest()->first();

        if ($user->hasRefusedInscription()) {
            Auth::logout();
            return redirect()->route('login')
                ->withErrors(['email' => "Votre demande d'inscription a été refusée."]);
        }

        if (! $user->canAccessStudentSpace()) {
            return Redirect::route('inscription.attente');
        }

        $etudiant = $this->getStudentEtudiant();

        return view('dashboard.etudiant.index', compact('user', 'inscription', 'etudiant'));
    }

    /**
     * Show notes for the authenticated student.
     */
    public function etudiantNotes(): RedirectResponse|View
    {
        $user = Auth::user();
        $etudiant = $this->getStudentEtudiant();

        if (! $etudiant) {
            return Redirect::route('inscription.attente');
        }

        $notes = $etudiant->notes()->with('matiere.module.semestre')->latest()->get();
        $average = $notes->whereNotNull('note_finale')->avg('note_finale');
        $average = $average !== null ? number_format($average, 2, ',', '.') : null;
        $validatedCount = $notes->whereIn('statut', ['validee', 'rattrapage_valide', 'reprise_valide'])->count();
        $currentSemestre = optional($notes->first()?->matiere?->module?->semestre)->libelle;

        return view('dashboard.etudiant.notes', compact('user', 'etudiant', 'notes', 'average', 'validatedCount', 'currentSemestre'));
    }

    /**
     * Show the bulletin page for the authenticated student.
     */
    public function etudiantBulletin(): RedirectResponse|View
    {
        $user = Auth::user();
        $etudiant = $this->getStudentEtudiant();

        if (! $etudiant) {
            return Redirect::route('inscription.attente');
        }

        $notes = $etudiant->notes()->with('matiere.module.semestre')->latest()->get();
        $average = $notes->whereNotNull('note_finale')->avg('note_finale');
        $average = $average !== null ? number_format($average, 2, ',', '.') : null;
        $bulletinReady = $notes->isNotEmpty();

        return view('dashboard.etudiant.bulletin', compact('user', 'etudiant', 'notes', 'average', 'bulletinReady'));
    }

    /**
     * Show modules for the authenticated student.
     */
    public function etudiantModules(): RedirectResponse|View
    {
        $user = Auth::user();
        $etudiant = $this->getStudentEtudiant();

        if (! $etudiant) {
            return Redirect::route('inscription.attente');
        }

        $modules = $etudiant->filiere?->modules()->with(['semestre', 'matieres'])->get() ?? collect();
        $semestreCount = $modules->pluck('semestre_id')->filter()->unique()->count();

        return view('dashboard.etudiant.modules', compact('user', 'etudiant', 'modules', 'semestreCount'));
    }

    /**
     * Show matières for the authenticated student.
     */
    public function etudiantMatieres(): RedirectResponse|View
    {
        $user = Auth::user();
        $etudiant = $this->getStudentEtudiant();

        if (! $etudiant) {
            return Redirect::route('inscription.attente');
        }

        $moduleIds = $etudiant->filiere?->modules()->pluck('id') ?? collect();
        $matieres = $moduleIds->isNotEmpty()
            ? Matiere::with('module')->whereIn('module_id', $moduleIds)->get()
            : collect();

        return view('dashboard.etudiant.matieres', compact('user', 'etudiant', 'matieres'));
    }

    /**
     * Show dettes for the authenticated student.
     */
    public function etudiantDettes(): RedirectResponse|View
    {
        $user = Auth::user();
        $etudiant = $this->getStudentEtudiant();

        if (! $etudiant) {
            return Redirect::route('inscription.attente');
        }

        $dettes = $etudiant->dettes()->with('matiere.module', 'module', 'semestre')->latest()->get();
        $pending = $dettes->where('statut', 'en_cours')->count();

        return view('dashboard.etudiant.dettes', compact('user', 'etudiant', 'dettes', 'pending'));
    }

    /**
     * Show emploi du temps for the authenticated student.
     */
    public function etudiantEmploi(): RedirectResponse|View
    {
        $user = Auth::user();
        $etudiant = $this->getStudentEtudiant();

        if (! $etudiant) {
            return Redirect::route('inscription.attente');
        }

        $semesterIds = $etudiant->filiere?->modules()->pluck('semestre_id')->filter()->unique() ?? collect();
        $emplois = $semesterIds->isNotEmpty()
            ? EmploiDuTemps::with('matiere.module', 'professeur', 'semestre', 'niveau')
            ->whereIn('semestre_id', $semesterIds)
            ->when($etudiant->niveau_id, fn($query) => $query->where('niveau_id', $etudiant->niveau_id))
            ->orderBy('jour')
            ->orderBy('heure_debut')
            ->get()
            : collect();

        return view('dashboard.etudiant.emploi', compact('user', 'etudiant', 'emplois'));
    }
}
