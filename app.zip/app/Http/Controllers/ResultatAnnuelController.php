<?php

namespace App\Http\Controllers;

use App\Models\ResultatAnnuel;
use App\Models\Etudiant;
use App\Models\Niveau;
use App\Services\ResultatAnnuelService;

use Illuminate\Http\Request;

class ResultatAnnuelController extends Controller
{
    protected $service;

    public function __construct(ResultatAnnuelService $service)
    {
        $this->service = $service;
    }

    public function index()
    {
        $resultats = ResultatAnnuel::with(['etudiant', 'niveau'])
            ->latest()
            ->paginate(10);

        return view('admin.resultats_annuels.index', compact('resultats'));
    }

    public function calculer(Etudiant $etudiant, Niveau $niveau)
    {
        // ici tu brancheras S1 + S2 depuis resultats_semestre
        $s1 = 0; // placeholder
        $s2 = 0; // placeholder

        $moyenne = $this->service->calculerMoyenne($s1, $s2);

        $decision = $this->service->decision($moyenne, $niveau->code);

        ResultatAnnuel::updateOrCreate(
            [
                'etudiant_id' => $etudiant->id,
                'niveau_id' => $niveau->id,
                'annee_academique' => date('Y'),
            ],
            [
                'moyenne_s1' => $s1,
                'moyenne_s2' => $s2,
                'moyenne_annuelle' => $moyenne,
                'decision' => $decision,
            ]
        );

        return back()->with('success', 'Résultat annuel calculé');
    }
}
