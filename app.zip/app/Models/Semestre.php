<?php

namespace App\Models;

use App\Models\Module;
use App\Models\Dette;
use App\Models\EmploiDuTemps;
use App\Models\ResultatSemestre;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Semestre extends Model
{
    use HasFactory;

    /**
     * Champs autorisés
     */
    protected $fillable = [

        'code',
        'libelle',
    ];

    /*
    |--------------------------------------------------------------------------
    | RELATIONS
    |--------------------------------------------------------------------------
    */

    /**
     * Un semestre possède plusieurs modules
     */
    public function modules()
    {
        return $this->hasMany(Module::class);
    }

    /**
     * Un semestre possède plusieurs dettes
     */
    public function dettes()
    {
        return $this->hasMany(Dette::class);
    }

    /**
     * Un semestre possède plusieurs emplois du temps
     */
    public function emploisDuTemps()
    {
        return $this->hasMany(EmploiDuTemps::class);
    }

    /**
     * Résultats académiques du semestre
     */
    public function resultatsSemestre()
    {
        return $this->hasMany(ResultatSemestre::class);
    }
}
