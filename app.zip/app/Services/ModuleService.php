<?php

namespace App\Services;

class ModuleService
{
    public function estValide(array $matieres): bool
    {
        foreach ($matieres as $matiere) {
            if (!$matiere->est_validee) {
                return false;
            }
        }

        return true;
    }
}
