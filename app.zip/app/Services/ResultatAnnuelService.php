<?php

namespace App\Services;

class ResultatAnnuelService
{
    /**
     * calcul moyenne annuelle
     */
    public function calculerMoyenne($s1, $s2)
    {
        return round(($s1 + $s2) / 2, 2);
    }

    /**
     * décision académique
     */
    public function decision($moyenne, $niveau)
    {
        if ($moyenne >= 10) {

            // cas L3
            if ($niveau === 'L3') {
                return 'diplome';
            }

            return 'admis';
        }

        if ($moyenne >= 5) {
            return 'ajourne';
        }

        return 'redoublant';
    }
}
