<?php

namespace App\Services;

use App\Models\Note;
use App\Models\Dette;

class DetteService
{
    /**
     * Créer dette si matière non validée
     */
    public function verifierDette(Note $note)
    {
        if ($note->statut === 'echec' || $note->statut === 'reprise') {

            Dette::updateOrCreate(
                [
                    'etudiant_id' => $note->etudiant_id,
                    'matiere_id' => $note->matiere_id,
                ],
                [
                    'module_id' => $note->matiere->module_id,
                    'semestre_id' => $note->matiere->module->semestre_id,
                    'statut' => 'en_cours',
                ]
            );
        }
    }

    /**
     * Lever dette
     */
    public function leverDette(Dette $dette)
    {
        $dette->update([
            'statut' => 'levee'
        ]);
    }
}
