<?php

namespace App\Services;

class NoteService
{
    public function calculer(float $cc, float $examen): float
    {
        return ($cc * 0.4) + ($examen * 0.6);
    }

    public function statut(float $note): string
    {
        if ($note >= 10) return 'validee';
        return 'rattrapage';
    }

    public function appliquerRattrapage(float $note): array
    {
        if ($note >= 10) {
            return [
                'statut' => 'rattrapage_valide',
                'note_finale' => 10
            ];
        }

        return [
            'statut' => 'reprise',
            'note_finale' => null
        ];
    }

    public function appliquerReprise(float $note): array
    {
        if ($note >= 10) {
            return [
                'statut' => 'reprise_valide',
                'note_finale' => 10
            ];
        }

        return [
            'statut' => 'echec',
            'note_finale' => $note
        ];
    }
}
