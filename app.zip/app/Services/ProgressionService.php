<?php

namespace App\Services;

class ProgressionService
{
    /**
     * déterminer statut progression
     */
    public function determinerStatut($decisionSemestre)
    {
        return match ($decisionSemestre) {

            'admis' => 'passage',

            'ajourne' => 'passage', // passe avec dettes

            'redoublant' => 'redoublement',

            default => 'en_cours',
        };
    }

    /**
     * vérifier diplôme L3
     */
    public function verifierDiplome($niveauCode, $decisionAnnuelle)
    {
        if ($niveauCode === 'L3' && $decisionAnnuelle === 'admis') {
            return 'diplome';
        }

        return null;
    }
}
