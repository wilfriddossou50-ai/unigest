<?php

namespace App\Services;

use App\Models\Note;

class ResultatSemestreService
{
    /**
     * calcul moyenne semestre
     */
    public function calculerMoyenne($etudiantId, $semestreId)
    {
        $notes = Note::where('etudiant_id', $etudiantId)
            ->whereHas('matiere.module', function ($q) use ($semestreId) {
                $q->where('semestre_id', $semestreId);
            })
            ->whereNotNull('note_finale')
            ->get();

        if ($notes->count() === 0) {
            return 0;
        }

        return round($notes->avg('note_finale'), 2);
    }

    /**
     * décision académique
     */
    public function decision($moyenne)
    {
        if ($moyenne >= 10) {
            return 'admis';
        }

        if ($moyenne >= 5) {
            return 'ajourne';
        }

        return 'redoublant';
    }
}
